# SECURITY-_management-
I developed the security management system using c++ 
